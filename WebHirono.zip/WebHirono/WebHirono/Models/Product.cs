﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebHirono.Models
{
    public class Product
    {
        public int ProductID { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public decimal Price { get; set; }

        public decimal? SalePrice { get; set; }
        public string? ImageUrl { get; set; }


        // ✅ Cho phép null vì chưa có khi submit form
        [NotMapped]
        public List<IFormFile>? ImageFiles { get; set; }


       

        [Required]
        public int BrandID { get; set; }

        public virtual Brand? Brand { get; set; }

        [Required]
        public int CategoryID { get; set; }

        public virtual Category? Category { get; set; }

        // ✅ Cho phép null nếu chưa upload ảnh phụ
        public virtual ICollection<ProductSize>? Sizes { get; set; }

        public virtual ICollection<ProductImage>? Gallery { get; set; }

        // ✅ Không lưu trong DB, dùng để upload ảnh chính
        [NotMapped]
        public IFormFile? ImageFile { get; set; }
    }
}
