﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebHirono.Models
{
    public class Order
    {
        public int OrderID { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public decimal TotalAmount { get; set; }

        // Liên kết với User
        public int? UserId { get; set; }
        public User? User { get; set; }

        [Required]
        public string Status { get; set; } = "Chờ xác nhận";

        [Required]
        public string FullName { get; set; }

        [Required]
        public string Address { get; set; }
        public DateTime OrderDate { get; set; }
        [Required]
        public string Phone { get; set; }
        public string PaymentMethod { get; set; } = "cod"; // mặc định COD

        public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
    }

}
