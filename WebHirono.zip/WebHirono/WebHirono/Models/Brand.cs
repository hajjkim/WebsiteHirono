﻿using System.ComponentModel.DataAnnotations;

namespace WebHirono.Models
{
    public class Brand
    {
        public int BrandID { get; set; }
       
        [Required]
        public string BrandName { get; set; }


        public virtual ICollection<Product>? Products { get; set; } = new List<Product>();
    }
}
