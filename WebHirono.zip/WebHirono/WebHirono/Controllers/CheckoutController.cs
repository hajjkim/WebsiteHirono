﻿
using Microsoft.AspNetCore.Mvc;
using WebHirono.Models;
using WebHirono.Extensions;

public class CheckoutController : Controller
{
    private readonly AppDbContext _context;

    public CheckoutController(AppDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("Cart") ?? new List<CartItem>();
        var userIdStr = HttpContext.Session.GetString("UserID");
        User currentUser = null;

        if (!string.IsNullOrEmpty(userIdStr))
        {
            int userId = int.Parse(userIdStr);
            currentUser = _context.Users.FirstOrDefault(u => u.UserID == userId);
        }

        ViewBag.CurrentUser = currentUser;
        return View(cart);
    }

    [HttpPost]
    public IActionResult PlaceOrder(string customerName, string address, string phone, string paymentMethod)
    {
        var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("Cart");
        if (cart == null || !cart.Any())
        {
            TempData["Error"] = "Giỏ hàng rỗng!";
            return RedirectToAction("Index");
        }

        var userIdStr = HttpContext.Session.GetString("UserID");
        int? userId = null;
        if (!string.IsNullOrEmpty(userIdStr))
        {
            userId = int.Parse(userIdStr);
        }

        var totalAmount = cart.Sum(item => item.Price * item.Quantity);

        var order = new Order
        {
            FullName = customerName,
            Address = address,
            Phone = phone,
            CreatedAt = DateTime.Now,
            Status = "Chờ xác nhận",
            UserId = userId,
            TotalAmount = totalAmount,
            PaymentMethod = paymentMethod,
            OrderItems = cart.Select(item => new OrderItem
            {
                ProductID = item.Product.ProductID,
                Quantity = item.Quantity,
                Price = item.Product.SalePrice ?? 0
            }).ToList()
        };

        _context.Orders.Add(order);
        _context.SaveChanges();

        HttpContext.Session.Remove("Cart");
        TempData["Success"] = "Đặt hàng thành công!";

        // 👉 chuyển sang trang cảm ơn kèm theo ID đơn hàng
        return RedirectToAction("Thanks", new { orderId = order.OrderID });
    }
    public IActionResult Thanks(int orderId)
    {
        var order = _context.Orders.FirstOrDefault(o => o.OrderID == orderId);
        if (order == null)
        {
            return NotFound();
        }

        return View(order); // Trả về View và truyền đối tượng Order
    }



}
