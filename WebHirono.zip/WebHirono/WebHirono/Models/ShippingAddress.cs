﻿using System.ComponentModel.DataAnnotations;

namespace WebHirono.Models
{
    public class ShippingAddress
    {
        [Key]
        public int AddressID { get; set; }
        public int UserID { get; set; }
        public virtual User? User { get; set; }

        [Required]
        public required string Street { get; set; }
        public string? District { get; set; }
        public string? City { get; set; }

        public string? Phone { get; set; }

        public bool IsDefault { get; set; } = true;
    }

}
