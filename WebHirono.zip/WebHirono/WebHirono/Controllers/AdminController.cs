﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebHirono.Models;

namespace WebHirono.Controllers
{
    public class DashboardController : Controller
    {
        private readonly AppDbContext _context;

        public DashboardController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            // Check if admin
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "admin")
            {
                return RedirectToAction("Index", "Home");
            }

            ViewBag.TotalProducts = await _context.Products.CountAsync();
            ViewBag.TotalCategories = await _context.Categories.CountAsync();
            ViewBag.TotalOrders = await _context.Orders.CountAsync();
            ViewBag.TotalUsers = await _context.Users.CountAsync();

            ViewBag.PendingOrders = await _context.Orders.Where(o => o.Status == "Pending").CountAsync();

            var recentOrders = await _context.Orders
                .Include(o => o.User)
                .OrderByDescending(o => o.CreatedAt)
                .Take(5)
                .ToListAsync();

            return View(recentOrders);
        }

        public async Task<IActionResult> Revenue()
        {
            var role = HttpContext.Session.GetString("UserRole");
            if (role != "admin")
            {
                return RedirectToAction("Index", "Home");
            }

            var completedOrders = await _context.Orders
                .Where(o => o.Status == "Completed")
                .Include(o => o.OrderItems)
                .ToListAsync();

            var totalRevenue = completedOrders.Sum(o => o.TotalAmount);
            var totalOrders = completedOrders.Count;
            var totalItems = completedOrders.Sum(o => o.OrderItems.Sum(i => i.Quantity));

            ViewBag.TotalRevenue = totalRevenue;
            ViewBag.TotalOrders = totalOrders;
            ViewBag.TotalItemsSold = totalItems;

            return View();
        }
    }
}
