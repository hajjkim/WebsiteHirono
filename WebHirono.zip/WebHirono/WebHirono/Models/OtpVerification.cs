﻿using System.ComponentModel.DataAnnotations;

namespace WebHirono.Models
{
    public class OtpVerification
    {
        public int OtpVerificationID { get; set; }

        [Required]
        public string Email { get; set; } = string.Empty;

        [Required]
        public string OtpCode { get; set; } = string.Empty;

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public DateTime ExpiresAt { get; set; }

        public bool IsUsed { get; set; } = false;

        public string Purpose { get; set; } = "LOGIN"; // LOGIN, PASSWORD_RESET, etc.
    }
}
