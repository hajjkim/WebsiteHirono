﻿using Microsoft.Extensions.Options;
using System.Net;
using System.Net.Mail;
using WebHirono.Models;

namespace WebHirono.Services
{
    public class EmailSender
    {
        private readonly EmailSettings _settings;

        public EmailSender(IOptions<EmailSettings> options)
        {
            _settings = options.Value;
        }

        public async Task SendOtpEmailAsync(string toEmail, string otpCode)
        {
            var mail = new MailMessage
            {
                From = new MailAddress(_settings.SenderEmail, _settings.SenderName),
                Subject = "Mã xác thực OTP",
                Body = $"Mã OTP của bạn là: <b>{otpCode}</b><br>Hiệu lực trong 5 phút.",
                IsBodyHtml = true
            };

            mail.To.Add(toEmail);

            using var smtp = new SmtpClient(_settings.SmtpServer, _settings.SmtpPort)
            {
                Credentials = new NetworkCredential(_settings.SenderEmail, _settings.SenderPassword),
                EnableSsl = true
            };

            await smtp.SendMailAsync(mail);
        }
    }
}
