﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebHirono.Models
{
    public class ProductImage
    {
        public int ProductImageID { get; set; }

        [Required]
        public string ImageUrl { get; set; }

        // Foreign key đến Product
        public int ProductID { get; set; }
        public virtual Product Product { get; set; }
    }
}
