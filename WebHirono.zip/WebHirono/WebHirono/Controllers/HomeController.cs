﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using WebHirono.Models;

namespace WebHirono.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext _context;

        public HomeController(ILogger<HomeController> logger, AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public async Task<IActionResult> Index(List<int>? priceRange, List<string>? brands, List<string>? sizes, string? sort, string? keyword)
        {
            var query = _context.Products
                .Include(p => p.Brand)
                .Include(p => p.Category)
                .Include(p => p.Sizes)
                .AsQueryable();

            // Lọc theo từ khóa nếu có
            if (!string.IsNullOrWhiteSpace(keyword))
            {
                query = query.Where(p =>
                    p.Name.ToLower().Contains(keyword.ToLower()) ||
                    p.Brand.BrandName.ToLower().Contains(keyword.ToLower()) ||
                    p.Category.CategoryName.ToLower().Contains(keyword.ToLower()));
            }

            // Lọc giá
            if (priceRange != null && priceRange.Any())
            {
                query = query.Where(p =>
                    (priceRange.Contains(1) && p.Price < 3_000_000) ||
                    (priceRange.Contains(2) && p.Price >= 3_000_000 && p.Price <= 10_000_000) ||
                    (priceRange.Contains(3) && p.Price > 10_000_000));
            }

            // Lọc thương hiệu
            if (brands != null && brands.Any())
            {
                query = query.Where(p => brands.Contains(p.Brand.BrandName));
            }

            // Lọc theo size
            if (sizes != null && sizes.Any())
            {
                query = query.Where(p => p.Sizes.Any(s => sizes.Contains(s.Size)));
            }

            // Gửi danh sách brand và size về ViewBag
            ViewBag.AllBrands = await _context.Brands.ToListAsync();

            // ✅ Lấy tất cả size từ bảng ProductSizes (distinct + order)
            var allSizes = await _context.ProductSizes
                .Select(s => s.Size)
                .Distinct()
                .OrderBy(s => s)
                .ToListAsync();

            ViewBag.AllSizes = allSizes;
            if (!string.IsNullOrWhiteSpace(keyword))
            {
                query = query.Where(p =>
                    p.Name.ToLower().Contains(keyword.ToLower()) ||
                    p.Brand.BrandName.ToLower().Contains(keyword.ToLower()) ||
                    p.Category.CategoryName.ToLower().Contains(keyword.ToLower()));
            }

            return View(await query.ToListAsync());
        }


        public IActionResult Sale()
        {
            var saleProducts = _context.Products
                .Where(p => p.SalePrice != null)
                .Include(p => p.Brand)
                .ToList();

            return View(saleProducts);
        }

        public async Task<IActionResult> Search(string keyword)
        {
            if (string.IsNullOrWhiteSpace(keyword))
            {
                return RedirectToAction("Index");
            }

            keyword = keyword.ToLower();

            var results = await _context.Products
                .Include(p => p.Brand)
                .Include(p => p.Category)
                .Where(p =>
                    p.Name.ToLower().Contains(keyword) ||
                    p.Brand.BrandName.ToLower().Contains(keyword) ||
                    p.Category.CategoryName.ToLower().Contains(keyword))
                .ToListAsync();

            ViewBag.Keyword = keyword;

            return View("SearchResults", results);
        }
        [HttpGet]
        public JsonResult Suggest(string term)
        {
            if (string.IsNullOrWhiteSpace(term))
                return Json(new List<string>());

            var suggestions = _context.Products
                .Where(p => p.Name.ToLower().Contains(term.ToLower()))
                .Select(p => p.Name)
                .Distinct()
                .Take(1)
                .ToList();

            return Json(suggestions);
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
