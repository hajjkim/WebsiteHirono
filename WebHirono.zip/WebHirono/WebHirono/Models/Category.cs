﻿using System.ComponentModel.DataAnnotations;

namespace WebHirono.Models
{
    public class Category
    {
        public int CategoryID  { get; set; }
        [Required]
        public string CategoryName { get; set; }

    }
}
