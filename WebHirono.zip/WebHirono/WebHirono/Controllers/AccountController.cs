﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;
using WebHirono.Models;
using WebHirono.Services;

namespace WebHirono.Controllers
{
    public class AccountController : Controller
    {
        private readonly AppDbContext _context;
        private readonly EmailSender _emailSender;

        public AccountController(AppDbContext context, EmailSender emailSender)
        {
            _context = context;
            _emailSender = emailSender;
        }

        public IActionResult Register() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                if (await _context.Users.AnyAsync(u => u.Email == model.Email))
                {
                    ModelState.AddModelError("Email", "Email đã tồn tại.");
                    return View(model);
                }

                var user = new User
                {
                    FullName = model.FullName,
                    Email = model.Email,
                    Password = HashPassword(model.Password),
                    Role = "customer",
                    Enabled = true,
                    CreatedAt = DateTime.Now
                };

                _context.Users.Add(user);
                await _context.SaveChangesAsync();

                HttpContext.Session.SetString("UserEmail", user.Email);
                HttpContext.Session.SetString("UserRole", user.Role);

                return RedirectToAction("Index", "Home");
            }
            return View(model);
        }

        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(string email, string password)
        {
            var hashedPassword = HashPassword(password);
            var user = await _context.Users.FirstOrDefaultAsync(u =>
                u.Email == email && u.Password == hashedPassword && u.Enabled);

            if (user == null)
            {
                ViewBag.Error = "Sai thông tin đăng nhập.";
                return View();
            }

            if (user.Role == "admin" || user.Role == "ROLE_ADMIN")
            {
                var otp = new Random().Next(100000, 999999).ToString();
                HttpContext.Session.SetString("OTP", otp);
                HttpContext.Session.SetString("AdminEmail", user.Email);
                HttpContext.Session.SetString("OTPExpired", DateTime.Now.AddMinutes(5).ToString());

                await _emailSender.SendOtpEmailAsync(user.Email, otp);
                return RedirectToAction("VerifyOtp");
            }

            // Người dùng thường thì đăng nhập luôn
            HttpContext.Session.SetString("UserID", user.UserID.ToString());
            HttpContext.Session.SetString("UserName", user.FullName);
            HttpContext.Session.SetString("UserRole", user.Role);

            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult VerifyOtp() => View();

        [HttpPost]
        public async Task<IActionResult> VerifyOtp(string otp)
        {
            var savedOtp = HttpContext.Session.GetString("OTP");
            var expiredStr = HttpContext.Session.GetString("OTPExpired");
            var email = HttpContext.Session.GetString("AdminEmail");

            if (otp != savedOtp)
            {
                ViewBag.Error = "Sai mã OTP.";
                return View();
            }

            if (!DateTime.TryParse(expiredStr, out var expired) || DateTime.Now > expired)
            {
                ViewBag.Error = "Mã OTP đã hết hạn.";
                return View();
            }

            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
            if (user == null)
            {
                ViewBag.Error = "Không tìm thấy người dùng.";
                return View();
            }

            HttpContext.Session.SetString("UserID", user.UserID.ToString());
            HttpContext.Session.SetString("UserName", user.FullName);
            HttpContext.Session.SetString("UserRole", user.Role);

            HttpContext.Session.Remove("OTP");
            HttpContext.Session.Remove("OTPExpired");
            HttpContext.Session.Remove("AdminEmail");

            return RedirectToAction("Index", "Dashboard");
        }

        [HttpPost]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashedBytes);
            }
        }
    }
}
