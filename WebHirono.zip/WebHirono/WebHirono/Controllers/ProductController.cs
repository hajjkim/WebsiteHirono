﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebHirono.Models;

namespace WebHirono.Controllers
{
    public class ProductController : Controller
    {
        private readonly AppDbContext _context;

        public ProductController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Product
        public IActionResult Index(int? categoryId)
        {
            var products = _context.Products.Include(p => p.Category).AsQueryable();

            if (categoryId.HasValue)
            {
                products = products.Where(p => p.CategoryID == categoryId.Value);
            }

            ViewBag.Categories = _context.Categories.ToList(); // nếu dùng cho bộ lọc

            return View(products.ToList());
        }


        // GET: Product/Details/5
        public IActionResult Details(int id)
        {
            var product = _context.Products
                .Include(p => p.Brand)
                .Include(p => p.Category)
                .Include(p => p.Gallery)
                .Include(p => p.Sizes)
                .FirstOrDefault(p => p.ProductID == id);

            if (product == null) return NotFound();

            // ✅ Lấy sản phẩm liên quan cùng Category (trừ sản phẩm hiện tại)
            var related = _context.Products
                .Where(p => p.CategoryID == product.CategoryID && p.ProductID != product.ProductID)
                .Take(4)
                .ToList();

            ViewBag.RelatedProducts = related;

            return View(product);
        }


        // GET: Product/Create
        public IActionResult Create()
{
    ViewBag.Brands = new SelectList(_context.Brands, "BrandID", "BrandName");
    ViewBag.Categories = new SelectList(_context.Categories, "CategoryID", "CategoryName");

    return View();
}


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product)
        {
            if (product.ImageFiles != null && product.ImageFiles.Count > 0)
            {
                product.Gallery = new List<ProductImage>();

                foreach (var file in product.ImageFiles)
                {
                    var fileName = Path.GetFileName(file.FileName);
                    var path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images", fileName);

                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    var imgUrl = "/images/" + fileName;
                    product.Gallery.Add(new ProductImage { ImageUrl = imgUrl });

                    if (string.IsNullOrEmpty(product.ImageUrl))
                    {
                        product.ImageUrl = imgUrl;
                    }
                }
            }

            if (ModelState.IsValid)
            {
                _context.Add(product);
                await _context.SaveChangesAsync(); // Phải lưu để có ProductID

                // Thêm size tự động theo danh mục
                var category = await _context.Categories.FindAsync(product.CategoryID);
                List<string> selectedSizes = new();

                if (category != null)
                {
                    switch (category.CategoryName?.ToLower())
                    {
                        case "giày nam":
                        case "giày nữ":
                            selectedSizes = new List<string> { "38", "39", "40", "41", "42", "43", "44" };
                            break;
                        case "quần áo":
                            selectedSizes = new List<string> { "S", "M", "L", "XL" };
                            break;
                    }

                    foreach (var size in selectedSizes)
                    {
                        _context.ProductSizes.Add(new ProductSize
                        {
                            ProductID = product.ProductID,
                            Size = size,
                            Stock = 0
                        });
                    }

                    await _context.SaveChangesAsync(); // lưu size
                }

                return RedirectToAction(nameof(Index));
            }

            ViewBag.Brands = new SelectList(_context.Brands, "BrandID", "BrandName", product.BrandID);
            ViewBag.Categories = new SelectList(_context.Categories, "CategoryID", "CategoryName", product.CategoryID);

            return View(product);
        }


        // GET: Product/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var product = await _context.Products
               .Include(p => p.Sizes)  // ✅ đúng

                .FirstOrDefaultAsync(p => p.ProductID == id);
            if (product == null) return NotFound();

            ViewBag.Brands = new SelectList(_context.Brands, "BrandID", "BrandName", product.BrandID);
            ViewBag.Categories = new SelectList(_context.Categories, "CategoryID", "CategoryName", product.CategoryID);
            return View(product);
        }

        // POST: Product/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Product product)
        {
            if (id != product.ProductID) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(product);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Products.Any(e => e.ProductID == id))
                        return NotFound();
                    else
                        throw;
                }
            }

            ViewBag.Brands = new SelectList(_context.Brands, "BrandID", "BrandName", product.BrandID);
            ViewBag.Categories = new SelectList(_context.Categories, "CategoryID", "CategoryName", product.CategoryID);
            return View(product);
        }

        // GET: Product/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var product = await _context.Products
                .Include(p => p.Brand)
                .Include(p => p.Category)
                .FirstOrDefaultAsync(p => p.ProductID == id);

            if (product == null) return NotFound();

            return View(product);
        }

        // POST: Product/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products.FindAsync(id);
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        //
        // GET: Product/UpdateSize/5
        public async Task<IActionResult> UpdateSize(int? id)
        {
            if (id == null) return NotFound();

            var product = await _context.Products
                .Include(p => p.Sizes)
                .Include(p => p.Category) // ✅ cần dòng này
                .FirstOrDefaultAsync(p => p.ProductID == id);

            if (product == null) return NotFound();

            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateSize(int id, List<int> sizeIds, List<int> stocks)
        {
            for (int i = 0; i < sizeIds.Count; i++)
            {
                var size = await _context.ProductSizes.FindAsync(sizeIds[i]);
                if (size != null)
                {
                    size.Stock = stocks[i];
                }
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Details), new { id });
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateStock(int id, int totalStock)
        {
            var size = await _context.ProductSizes.FirstOrDefaultAsync(s => s.ProductID == id);
            if (size != null)
            {
                size.Stock = totalStock;
                await _context.SaveChangesAsync();
            }
            else
            {
                // Nếu sản phẩm chưa có bản ghi size nào, tạo mới
                _context.ProductSizes.Add(new ProductSize
                {
                    ProductID = id,
                    Size = "Default", // hoặc để trống "", hoặc "ALL"
                    Stock = totalStock
                });
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Details), new { id });
        }
        


    }
}