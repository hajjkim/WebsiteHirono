﻿using WebHirono.Models;

public interface IOtpService
{
    string GenerateOtp();
    void SaveOtp(User user, string otpCode);
    bool VerifyOtp(User user, string otpInput);
}
