﻿using Microsoft.AspNetCore.Mvc;
using WebHirono.Extensions;
using WebHirono.Models;

namespace WebHirono.Controllers
{
    public class CartController : Controller
    {
        private readonly AppDbContext _context;

        public CartController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("Cart") ?? new List<CartItem>();
            return View(cart);
        }

        [HttpPost]
        public IActionResult AddToCart(int productId, string size, int quantity = 1)
        {
            var product = _context.Products.FirstOrDefault(p => p.ProductID == productId);
            if (product == null) return NotFound();

            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("Cart") ?? new List<CartItem>();

            // ✅ Tìm theo cả ProductId và Size
            var existingItem = cart.FirstOrDefault(c => c.ProductId == productId && c.Size == size);
            if (existingItem != null)
            {
                existingItem.Quantity += quantity;
            }
            else
            {
                cart.Add(new CartItem
                {
                    ProductId = product.ProductID,
                    ProductName = product.Name,
                    ImageUrl = product.ImageUrl,
                    Price = product.SalePrice ?? 0,
                    Quantity = quantity,
                    Size = size,
                    Product = product
                });
            }

            HttpContext.Session.SetObjectAsJson("Cart", cart);
            return RedirectToAction("Index", "Cart");
        }


        [HttpPost]
        public IActionResult UpdateQuantity(int id, int quantity)
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("Cart");
            var item = cart?.FirstOrDefault(p => p.ProductId == id);

            if (item != null)
            {
                item.Quantity = quantity;
                HttpContext.Session.SetObjectAsJson("Cart", cart);
                HttpContext.Session.SetInt32("CartCount", cart.Sum(i => i.Quantity));
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult RemoveItem(int id)
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("Cart");
            cart?.RemoveAll(p => p.ProductId == id);

            HttpContext.Session.SetObjectAsJson("Cart", cart);
            HttpContext.Session.SetInt32("CartCount", cart?.Sum(i => i.Quantity) ?? 0);

            return RedirectToAction("Index");
        }
    }
}
