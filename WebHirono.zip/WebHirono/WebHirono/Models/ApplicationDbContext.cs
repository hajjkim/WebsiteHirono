﻿using Microsoft.EntityFrameworkCore;

namespace WebHirono.Models
{
    public class AppDbContext : DbContext
    {

        public AppDbContext(DbContextOptions<AppDbContext> options)
           : base(options)
        {
        }
        public DbSet<Brand> Brands { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<ProductSize> ProductSizes { get; set; }
        public DbSet<Category> Categories { get; set; } // ✅ thêm dòng này
        public DbSet<User> Users { get; set; }
        public DbSet<ShippingAddress> ShippingAddresses { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Brand>().Property(b => b.BrandName).HasMaxLength(100).IsRequired();
            modelBuilder.Entity<Product>().Property(p => p.Name).HasMaxLength(255).IsRequired();
            modelBuilder.Entity<Order>()
      .HasMany(o => o.OrderItems)  // 🔄 Đổi từ o.Items → o.OrderItems
      .WithOne(i => i.Order)
      .HasForeignKey(i => i.OrderID);



            // ✅ cấu hình Category
            modelBuilder.Entity<Category>().Property(c => c.CategoryName).HasMaxLength(100).IsRequired();
        }

    }
}
