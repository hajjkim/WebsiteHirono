﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

using WebHirono.Models;
using WebHirono.Services;

var builder = WebApplication.CreateBuilder(args);

// Thêm AppDbContext
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Cấu hình Session
builder.Services.AddSession(); // ✅ thêm dòng này
builder.Services.AddHttpContextAccessor(); // ✅ nếu bạn dùng @inject IHttpContextAccessor trong view
//otp
builder.Services.Configure<EmailSettings>(builder.Configuration.GetSection("EmailSettings"));
builder.Services.AddScoped<EmailSender>();

// Add MVC
builder.Services.AddControllersWithViews();
builder.Services.AddAuthentication("MyCookie")
    .AddCookie("MyCookie", options =>
    {
        options.LoginPath = "/Account/Login";
        options.LogoutPath = "/Account/Logout";
    });

builder.Services.AddHttpContextAccessor();
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Services.Configure<EmailSettings>(
    builder.Configuration.GetSection("EmailSettings"));
builder.Services.AddSingleton<EmailSender>();

var app = builder.Build();

// Middleware pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
    app.UseDeveloperExceptionPage();
}
builder.Services.AddHttpContextAccessor();

app.UseHttpsRedirection();
app.UseStaticFiles(); // nên có nếu bạn dùng wwwroot

app.UseRouting();
app.UseSession();      // ✅ bắt buộc đặt sau UseRouting
app.UseAuthorization();

// Map route
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
//momo
app.MapControllerRoute(
    name: "momo-return",
    pattern: "momo/return",
    defaults: new { controller = "Payment", action = "ReturnUrl" });

app.MapControllerRoute(
    name: "momo-notify",
    pattern: "momo/notify",
    defaults: new { controller = "Payment", action = "Notify" });

// Nếu có MapStaticAssets thì giữ lại
app.MapStaticAssets(); // nếu không dùng, có thể xoá dòng này

app.Run();
