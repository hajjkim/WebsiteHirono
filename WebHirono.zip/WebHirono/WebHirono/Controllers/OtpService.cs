﻿using WebHirono.Models;

public class OtpService : IOtpService
{
    private readonly AppDbContext _context;

    public OtpService(AppDbContext context)
    {
        _context = context;
    }

    public string GenerateOtp()
    {
        return new Random().Next(100000, 999999).ToString();
    }

    public void SaveOtp(User user, string otpCode)
    {
        user.OtpCode = otpCode;
        user.OtpExpiry = DateTime.Now.AddMinutes(5);
        _context.SaveChanges();
    }

    public bool VerifyOtp(User user, string otpInput)
    {
        return user.OtpCode == otpInput && user.OtpExpiry > DateTime.Now;
    }
}
