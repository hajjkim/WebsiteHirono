﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebHirono.Models
{
    public class ProductSize
    {
        public int ProductSizeID { get; set; }

        [Required]
        [StringLength(10)]
        public string Size { get; set; }  // Ví dụ: "M", "L", "42", v.v.

        [Required]
        public int Stock { get; set; }

        // Foreign Key
        public int ProductID { get; set; }

        // Navigation Property
        public virtual Product Product { get; set; }
    }
}
