﻿using System.ComponentModel.DataAnnotations;

namespace WebHirono.Models
{
    public class User
    {
        [Key]
        public int UserID { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập họ tên")]
        public string FullName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Vui lòng nhập email")]
        [EmailAddress(ErrorMessage = "Email không hợp lệ")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Vui lòng nhập mật khẩu")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;
        public string? Phone { get; set; }
        public string? Address { get; set; }

        public bool Enabled { get; set; } = true;

        [Required]
        public string Role { get; set; } = "ROLE_CUSTOMER";

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public string? ImgPath { get; set; }
        public string? OtpCode { get; set; }
        public DateTime? OtpExpiry { get; set; }
        // Navigation: Một user có nhiều địa chỉ giao hàng
        public virtual ICollection<ShippingAddress>? Addresses { get; set; }
    }
}
